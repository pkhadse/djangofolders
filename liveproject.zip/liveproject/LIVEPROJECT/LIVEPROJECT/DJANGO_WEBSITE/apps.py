from django.apps import AppConfig


class DjangoWebsiteConfig(AppConfig):
    name = 'DJANGO_WEBSITE'
