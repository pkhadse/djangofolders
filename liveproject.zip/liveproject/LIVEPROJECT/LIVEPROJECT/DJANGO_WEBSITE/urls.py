from django.urls import path
from. import views

urlpatterns = [
    path('',views.hi , name='what_are_you_looking_for?'),
]
